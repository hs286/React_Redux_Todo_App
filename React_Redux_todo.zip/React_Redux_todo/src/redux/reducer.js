import * as types from "./actionType";

const initialState = {
  users: [],
  oneuser: [],
};

const userReducers = (state = initialState, action) => {
  switch (action.type) {
    case types.GET_USERS:
      return {
        ...state,
        users: action.payload,
      };
    case types.DELETE_USERS:
      return {
        ...state,
      };
    case types.ADD_USERS:
      return {
        ...state,
      };
    case types.GET_SINGLE_USERS:
      return {
        ...state,
        oneuser: action.payload,
      };
    case types.UPDATE_USERS:
      return {
        ...state,
      };
    default:
      return state;
  }
};
export default userReducers;
