export const GET_USERS = "GET-USERS";
export const DELETE_USERS = "DELETE-USERS";
export const ADD_USERS = "ADD-USERS";
export const GET_SINGLE_USERS = "GET-SINGLE-USERS";
export const UPDATE_USERS = "UPDATE-USERS";
