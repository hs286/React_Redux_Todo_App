import * as types from "./actionType";
import axios from "axios";
const gettingUsers = (users) => ({
  type: types.GET_USERS,
  payload: users,
});

export const getUsers = () => {
  return function (dispatch) {
    axios
      .get(`${process.env.REACT_APP_API}`)
      .then((resp) => {
        dispatch(gettingUsers(resp.data));
      })
      .catch((error) => console.log(error));
  };
};

const userDeleted = () => ({
  type: types.DELETE_USERS,
});

export const deleteUsers = (id) => {
  return function (dispatch) {
    axios
      .delete(`${process.env.REACT_APP_API}/${id}`)
      .then((resp) => {
        dispatch(userDeleted(resp.data));
        dispatch(getUsers());
      })
      .catch((error) => console.log(error));
  };
};

const userAdded = () => ({
  type: types.ADD_USERS,
});

export const addUsers = (user) => {
  return function (dispatch) {
    axios
      .post(`${process.env.REACT_APP_API}`, user)
      .then((resp) => {
        dispatch(userAdded());
      })
      .catch((error) => console.log(error));
  };
};

const gettingSingleUser = (user) => ({
  type: types.GET_SINGLE_USERS,
  payload: user,
});

export const getsingleUsers = (id) => {
  return function (dispatch) {
    axios
      .get(`${process.env.REACT_APP_API}/${id}`)
      .then((resp) => {
        console.log(resp.data);
        dispatch(gettingSingleUser(resp.data));
      })
      .catch((error) => console.log(error));
  };
};

const updatedUser = () => ({
  type: types.UPDATE_USERS,
});

export const updateUsers = (user, id) => {
  return function (dispatch) {
    axios
      .put(`${process.env.REACT_APP_API}/${id}`, user)
      .then((resp) => {
        dispatch(updatedUser());
      })
      .catch((error) => console.log(error));
  };
};
