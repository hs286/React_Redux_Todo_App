import React, { useState, useEffect } from "react";
import {  useHistory, useParams } from "react-router-dom";
import { useSelector, useDispatch } from "react-redux";
import { getsingleUsers, updateUsers } from "./redux/actions";

function Update() {
  const dispatch = useDispatch();
  const users = useSelector((state) => state.user.oneuser);
  const history = useHistory();
  const { id } = useParams();
  useEffect(() => {
    dispatch(getsingleUsers(id));
  }, [id,dispatch]);
  const [title, setTitle] = useState("");
  const [body, setBody] = useState("");
  useEffect(() => {
    if (users) {
      setBody(users.body);
      setTitle(users.title);
    }
    console.log(users);
  }, [users]);

  const handleSubmit = (e) => {
    e.preventDefault();
    users.title = title;
    users.body = body;
    dispatch(updateUsers(users, id));
    history.push("/");
  };

  return (
    <div>
      <div className="create">
        <h2>Update Blog</h2>
        {
          <form onSubmit={handleSubmit}>
            <div>
              <label>Blog title:</label>
              <input
                type="text"
                required
                value={title}
                onChange={(e) => setTitle(e.target.value)}
              />
              <label>Blog body:</label>
              <textarea
                required
                type="text"
                value={body}
                onChange={(e) => setBody(e.target.value)}
              ></textarea>
              <button>Update</button>
            </div>
          </form>
        }
      </div>
    </div>
  );
}

export default Update;
