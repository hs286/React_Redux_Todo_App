import { useState } from "react";
import { useHistory } from "react-router-dom";
import uuid from "react-uuid";
import { useDispatch } from "react-redux";
import { addUsers } from "./redux/actions";

const Create = () => {
  const dispatch = useDispatch();
  const history = useHistory();
  const [state, setState] = useState({
    title: "",
    body: "",
  });
  const { title, body} = state;
  const handleInputChange = (e) => {
    setState({ ...state, [e.target.name]: e.target.value });
  };
  const handleSubmit = (e) => {
    e.preventDefault();
  };
  const handleClick = () => {
    if (title == "" && body == "") {
      window.alert("write all");
    } else {
      dispatch(addUsers(state));
      history.push("/");
    }
  };
  return (
    <div className="create">
      <h2>Add a New Blog</h2>
      <form onSubmit={handleSubmit}>
        <label>Blog title:</label>
        <input
          type="text"
          required
          name="title"
          value={title}
          onChange={handleInputChange}
        />
        <label>Blog body:</label>
        <textarea
          required
          name="body"
          value={body}
          onChange={handleInputChange}
        ></textarea>
        <button onClick={handleClick}>Add Blog</button>
      </form>
    </div>
  );
};

export default Create;
