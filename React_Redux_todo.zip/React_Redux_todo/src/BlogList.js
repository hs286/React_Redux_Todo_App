import React, { useEffect } from "react";
import { Link } from "react-router-dom";
import { useSelector, useDispatch } from "react-redux";
import { deleteUsers, loadUsers } from "./redux/actions";
import { useHistory } from "react-router-dom";

function BlogList({ users }) {
  //console.log(users);
  const history = useHistory();
  const dispatch = useDispatch();
  const handleDelete = (id) => {
    if (window.confirm("Are you sure you wanted the user to be delete ")) {
      dispatch(deleteUsers(id));
    }
  };
  return (
    <div className="create">
      {users!==undefined &&
        users.map((users) => (
          <div className="blog-preview" key={users.id}>
            <h2>Title</h2>
            <p>{users.title}</p>

            <h4>Description:</h4>
            <p>{users.body}</p>

            <button
              onClick={() => {
                handleDelete(users.id);
              }}
            >
              delete
            </button>
            <button onClick={() => history.push("/update/"+users.id)}>
              Edit
            </button>
          </div>
        ))}
    </div>
  );
}

export default BlogList;
