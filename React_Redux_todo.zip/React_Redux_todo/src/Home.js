import BlogList from "./BlogList";
import React from "react";
import { useEffect } from "react";
import { useSelector, useDispatch } from "react-redux";
import { getUsers } from "./redux/actions";
function Home() {
  const dispatch = useDispatch();
  const  {users}  = useSelector((state) => state.user);
  useEffect(() => {
    dispatch(getUsers());
  });
  return (
    <div className="home">
      <BlogList users={users} />
    </div>
  );
}

export default Home;
